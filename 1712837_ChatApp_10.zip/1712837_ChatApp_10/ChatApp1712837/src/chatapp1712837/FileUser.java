/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp1712837;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author mangv
 */
public class FileUser {
    public List ReadUser(File file) throws IOException {
        // open file input stream
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                      new FileInputStream(file), "utf-8"));
        // read file line by line
        String line = null;
        Scanner scanner = null;
        int index = 0;
        List<User> userList = new ArrayList<>();
        reader.readLine();
        while ((line = reader.readLine()) != null) {
            User u = new User();
            scanner = new Scanner(line);
            scanner.useDelimiter(",");
            while (scanner.hasNext()) {
                String data = scanner.next();
                if (index == 0) {
                    u.setUsername(data);
                } else if (index == 1) {
                    u.setPassword(data);
                } else if (index == 2) {
                    u.setPhone(data);
                } else if (index == 3) {
                    u.setPort(Integer.valueOf(data));
                } else {
                }
                index++;
            }
            index = 0;
            userList.add(u);
        }
        reader.close();
        return userList;
    };
    public void WriteUser(File file, User user) throws IOException{
        Writer out = new OutputStreamWriter( new FileOutputStream(file,true), "UTF-8");
        out.write(user.getUsername()+","+user.getPassword()+","+user.getPhone()+","+user.getPort()+"\n");
        out.close();
    };
}
