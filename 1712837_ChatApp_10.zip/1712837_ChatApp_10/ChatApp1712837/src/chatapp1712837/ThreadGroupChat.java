/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp1712837;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mangv
 */
public class ThreadGroupChat extends Thread {

    private Thread thread;
    private String threadName;
    private DatagramSocket mySocket;

    ThreadGroupChat(String name, DatagramSocket socket) {
        threadName = name;
        mySocket = socket;

    }

    public void run() {
        send sendServer = new send();
        List <String[]>memberList = new ArrayList();
        try {
            while (true) {
                byte[] receivedBuf = new byte[500];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBuf, receivedBuf.length);
                mySocket.receive(receivedPacket);
                String receivedmess = new String(receivedPacket.getData(), 0, receivedBuf.length,StandardCharsets.UTF_8).trim();
                if(receivedmess.equals("ping-connect-group"))
                {
                    byte[] usernameBuf = new byte[100];
                    DatagramPacket usernamePacket = new DatagramPacket(usernameBuf, usernameBuf.length);
                    mySocket.receive(usernamePacket);
                    String received = new String(usernamePacket.getData(), 0, usernameBuf.length,StandardCharsets.UTF_8).trim();
                    String[] member = received.split("\\s");
                    memberList.add(member);
                    for(String[] mem : memberList)
                    {
                        sendServer.sendmessage(mySocket, member[2]+" đã tham gia", mem[0], Integer.valueOf(mem[1]));
                    }
                }
                else
                {
                    for(String[] mem : memberList)
                    {
                        sendServer.sendmessage(mySocket, receivedmess, mem[0], Integer.valueOf(mem[1]));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this, threadName);
            thread.start();
        }
    }

}
