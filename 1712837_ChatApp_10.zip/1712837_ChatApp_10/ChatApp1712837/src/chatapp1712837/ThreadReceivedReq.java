/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp1712837;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 *
 * @author mangv
 */
public class ThreadReceivedReq extends Thread {

    private Thread thread;
    private String threadName;
    private DatagramSocket mySocket;
    private String myName;

    ThreadReceivedReq(String name, DatagramSocket socket, String myname) {
        threadName = name;
        mySocket = socket;
        myName = myname;
        
    }

    public void run() {
        try {
            while (true) {
                byte[] receivedBuf = new byte[100];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBuf, receivedBuf.length);
                mySocket.receive(receivedPacket);
                String received = new String(receivedPacket.getData(),0,receivedBuf.length).trim();
                String[] part = received.split("\\s");
                int frPort = Integer.parseInt(part[0]);
                int myPort = Integer.parseInt(part[1]);
                DatagramSocket socketChat = new DatagramSocket(myPort);
                ChatWindow chatWindow = new ChatWindow(socketChat, part[2], myName, receivedPacket.getAddress().getHostAddress() , frPort);
                chatWindow.setVisible(true);
                chatWindow.setLocationRelativeTo(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this, threadName);
            thread.start();
        }
    }

}
