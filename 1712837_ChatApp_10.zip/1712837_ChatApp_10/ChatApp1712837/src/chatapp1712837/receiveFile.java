/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp1712837;

import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 *
 * @author mangv
 */
public class receiveFile {

    public void receivefile(DatagramSocket mySocket, File file, int size, String host, int port) {
        try {
            FileOutputStream fileout = new FileOutputStream(file);
            byte[] receivedBuf = new byte[100000000];
            DatagramPacket receivedPacket = new DatagramPacket(receivedBuf, size);
            mySocket.receive(receivedPacket);
            fileout.write(receivedBuf, 0, size);
            fileout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
