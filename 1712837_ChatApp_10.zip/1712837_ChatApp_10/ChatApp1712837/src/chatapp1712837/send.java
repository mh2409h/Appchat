/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp1712837;

import java.io.File;
import java.io.FileInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Random;

/**
 *
 * @author mangv
 */
public class send {
    
    public void sendmessage(DatagramSocket mySocket, String text, String host, int port) {
        try {
            InetAddress add = InetAddress.getByName(host);
            byte[] sentBuf = new byte[500];
            sentBuf = text.getBytes(StandardCharsets.UTF_8);
            DatagramPacket sentPacket = new DatagramPacket(sentBuf, sentBuf.length, add, port);
            mySocket.send(sentPacket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void sendfile(DatagramSocket mySocket, File file, String host, int port) {
        try {
            FileInputStream in = new FileInputStream(file);
            InetAddress add = InetAddress.getByName(host);
            byte[] sentBuf = new byte[100000000];
            in.read(sentBuf);
            DatagramPacket sentPacket = new DatagramPacket(sentBuf, (int) file.length(), add, port);
            System.out.print(sentPacket.getLength());
            mySocket.send(sentPacket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
