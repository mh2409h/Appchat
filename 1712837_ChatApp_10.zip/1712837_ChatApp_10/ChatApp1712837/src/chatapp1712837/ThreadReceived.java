/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp1712837;

import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author mangv
 */
public class ThreadReceived extends Thread {

    private Thread thread;
    private String threadName;
    private DatagramSocket mySocket;
    private String host;
    private int port;
    private JTextArea jText;

    ThreadReceived(String name, DatagramSocket socket, String Host, int Port, JTextArea text) {
        threadName = name;
        mySocket = socket;
        host = Host;
        port = Port;
        jText = text;

    }

    public void run() {
        try {
            while (true) {
                byte[] receivedBuf = new byte[500];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBuf, receivedBuf.length);
                mySocket.receive(receivedPacket);
                String receivedmess = new String(receivedPacket.getData(), 0, receivedBuf.length,StandardCharsets.UTF_8).trim();
                if (receivedmess.equals("message-request-send-file")) {
                    byte[] receivedFileSize = new byte[500];
                    DatagramPacket receivedPacket2 = new DatagramPacket(receivedFileSize, receivedFileSize.length);
                    mySocket.receive(receivedPacket2);
                    String receivedFileSizeStr = new String(receivedPacket2.getData(), 0, receivedFileSize.length,StandardCharsets.UTF_8).trim();
                    int fileSize = Integer.parseInt(receivedFileSizeStr);
                    JFileChooser jFileChooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                    int returnValue = jFileChooser.showSaveDialog(null);
                    if (returnValue == jFileChooser.APPROVE_OPTION) {
                        File file = new File(jFileChooser.getSelectedFile().getPath());
                        receiveFile receivefile = new receiveFile();
                        receivefile.receivefile(mySocket, file, fileSize, host, port);
                    }
                    else {
                        mySocket.receive(receivedPacket);
                    }
                } else {
                    if (receivedPacket.getAddress().getHostAddress().equals(host) && receivedPacket.getPort() == (port)) {
                    jText.setText(jText.getText() + "\n" + receivedmess + "\n");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this, threadName);
            thread.start();
        }
    }

}
